var searchData=
[
  ['sockctrl_320',['sockctrl',['../structdaemon__slpars.html#a6e7d765aa9745c34f5eb6d7fd8cbd22f',1,'daemon_slpars']]],
  ['ssl_321',['ssl',['../structdaemon__slpars.html#ab03fc303d462174dbd1286c1994bdf66',1,'daemon_slpars']]]
];
