var searchData=
[
  ['oneshot_5fuserdata_58',['oneshot_userdata',['../structoneshot__userdata.html',1,'']]],
  ['opt_5fstate_5ft_59',['opt_state_t',['../structopt__state__t.html',1,'']]],
  ['option_5fheader_60',['option_header',['../structoption__header.html',1,'']]]
];
