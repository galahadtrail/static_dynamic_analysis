var indexSectionsWithContent =
{
  0: "_abcdeghilmnopqrstuvy",
  1: "_abcdehilmnopqrstuvy",
  2: "v",
  3: "insy",
  4: "bcgl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Variables",
  4: "Pages"
};

